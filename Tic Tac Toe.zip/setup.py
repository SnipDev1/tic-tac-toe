import pip

pip.main(["install", "PythonTurtle", "--user"])